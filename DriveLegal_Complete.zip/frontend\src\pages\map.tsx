import Head from 'next/head';
import React, { useEffect, useRef, useState } from 'react';
import { Map as MapIcon, Navigation, AlertTriangle, Info } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Spinner } from '@/components/ui/Spinner';
import { useLocationStore } from '@/store/locationStore';

// We load Leaflet dynamically to avoid SSR issues
const MOCK_ZONES = [
  { id: 1, name: 'Connaught Place Speed Zone',    zone_type: 'speed_limit',   latitude: 28.6315, longitude: 77.2167, radius: 500, limit: '30 km/h' },
  { id: 2, name: 'IGI Airport No-Honking Zone',   zone_type: 'no_honking',    latitude: 28.5562, longitude: 77.0999, radius: 800, limit: null },
  { id: 3, name: 'Lajpat Nagar Enforcement Zone', zone_type: 'enforcement',   latitude: 28.5677, longitude: 77.2432, radius: 600, limit: null },
  { id: 4, name: 'Chandni Chowk School Zone',     zone_type: 'school_zone',   latitude: 28.6506, longitude: 77.2300, radius: 400, limit: '20 km/h' },
  { id: 5, name: 'DND Flyway Speed Camera',       zone_type: 'speed_camera',  latitude: 28.5921, longitude: 77.3200, radius: 200, limit: '80 km/h' },
];

const ZONE_COLORS: Record<string, string> = {
  speed_limit:  '#f59e0b',
  no_honking:   '#6366f1',
  enforcement:  '#ef4444',
  school_zone:  '#22c55e',
  speed_camera: '#38bdf8',
};

const ZONE_LABELS: Record<string, string> = {
  speed_limit:  'Speed Limit',
  no_honking:   'No Honking',
  enforcement:  'Enforcement Zone',
  school_zone:  'School Zone',
  speed_camera: 'Speed Camera',
};

export default function MapPage() {
  const { countryName } = useLocationStore();
  const mapRef     = useRef<HTMLDivElement>(null);
  const leafletRef = useRef<any>(null);
  const [mapReady, setMapReady] = useState(false);
  const [selected, setSelected] = useState<typeof MOCK_ZONES[0] | null>(null);

  useEffect(() => {
    if (typeof window === 'undefined' || leafletRef.current) return;

    import('leaflet').then((L) => {
      if (!mapRef.current || leafletRef.current) return;

      // Dark tile layer
      const map = L.map(mapRef.current, { zoomControl: false }).setView([28.6139, 77.2090], 11);
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 19,
      }).addTo(map);

      L.control.zoom({ position: 'bottomright' }).addTo(map);

      // Draw zones
      MOCK_ZONES.forEach((zone) => {
        const color = ZONE_COLORS[zone.zone_type] || '#3b82f6';

        L.circle([zone.latitude, zone.longitude], {
          radius: zone.radius,
          color,
          fillColor: color,
          fillOpacity: 0.15,
          weight: 2,
        }).addTo(map)
          .bindPopup(`
            <div style="font-family:Inter,sans-serif;min-width:160px">
              <strong style="color:#f1f5f9">${zone.name}</strong><br/>
              <span style="color:#94a3b8;font-size:11px">${ZONE_LABELS[zone.zone_type] ?? zone.zone_type}</span>
              ${zone.limit ? `<br/><span style="color:#f59e0b;font-size:12px">Limit: ${zone.limit}</span>` : ''}
            </div>
          `);

        // Marker dot
        const icon = L.divIcon({
          className: '',
          html: `<div style="width:12px;height:12px;border-radius:50%;background:${color};border:2px solid white;box-shadow:0 0 6px ${color}"></div>`,
          iconSize: [12, 12],
          iconAnchor: [6, 6],
        });
        L.marker([zone.latitude, zone.longitude], { icon }).addTo(map);
      });

      leafletRef.current = map;
      setMapReady(true);
    });

    return () => {
      leafletRef.current?.remove();
      leafletRef.current = null;
    };
  }, []);

  return (
    <>
      <Head>
        <title>Enforcement Map — DriveLegal</title>
        <meta name="description" content="View enforcement zones, speed cameras, and school zones on an interactive map." />
      </Head>

      {/* Leaflet CSS */}
      <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

      <div className="flex flex-col h-[calc(100vh-4rem)]">
        {/* Header */}
        <div className="flex-shrink-0 border-b border-white/5 bg-surface-900/60 backdrop-blur-md px-4 py-3">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-500/30 flex items-center justify-center">
                <MapIcon className="w-4 h-4 text-sky-400" />
              </div>
              <div>
                <h1 className="text-sm font-bold text-white leading-none">Enforcement Map</h1>
                <p className="text-[11px] text-slate-500 mt-0.5">{countryName} · {MOCK_ZONES.length} zones loaded</p>
              </div>
            </div>

            {/* Legend */}
            <div className="hidden sm:flex items-center gap-3 flex-wrap">
              {Object.entries(ZONE_LABELS).map(([key, label]) => (
                <div key={key} className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full border border-white/20" style={{ background: ZONE_COLORS[key] }} />
                  <span className="text-xs text-slate-400">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Map container */}
        <div className="relative flex-1">
          {!mapReady && (
            <div className="absolute inset-0 flex items-center justify-center bg-surface-950 z-10">
              <div className="flex flex-col items-center gap-3">
                <Spinner size="lg" />
                <p className="text-slate-400 text-sm">Loading map…</p>
              </div>
            </div>
          )}
          <div ref={mapRef} className="w-full h-full" id="enforcement-map" />

          {/* Info overlay */}
          <div className="absolute bottom-4 left-4 z-[400]">
            <div className="glass-sm px-3 py-2 flex items-center gap-2 text-xs text-slate-400">
              <Info className="w-3.5 h-3.5 text-sky-400" />
              Click any zone circle for details
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
