"""add_phase2_tables

Revision ID: 002_phase2_features
Revises: 001_initial
Create Date: 2026-05-03

Adds:
  - blockchain_records
  - badges
  - user_badges
  - leaderboard
  - insurance_partners
"""
from alembic import op
import sqlalchemy as sa

revision = "002_phase2_features"
down_revision = None   # set to your last revision ID
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── blockchain_records ─────────────────────────────────────────────────
    op.create_table(
        "blockchain_records",
        sa.Column("id",             sa.Integer(),     primary_key=True),
        sa.Column("user_id",        sa.Integer(),     sa.ForeignKey("users.id"), nullable=True, index=True),
        sa.Column("violation_id",   sa.Integer(),     sa.ForeignKey("user_violations.id"), nullable=True, index=True),
        sa.Column("record_id_hash", sa.String(128),   unique=True, index=True, nullable=False),
        sa.Column("tx_hash",        sa.String(128),   nullable=True),
        sa.Column("driver_did",     sa.String(255),   nullable=False),
        sa.Column("violation_code", sa.String(64),    nullable=False),
        sa.Column("country_code",   sa.String(10),    nullable=False),
        sa.Column("data_hash",      sa.String(128),   nullable=False),
        sa.Column("block_number",   sa.Integer(),     nullable=True),
        sa.Column("is_mock",        sa.Boolean(),     default=True),
        sa.Column("created_at",     sa.DateTime(),    default=sa.func.now()),
    )

    # ── badges ─────────────────────────────────────────────────────────────
    op.create_table(
        "badges",
        sa.Column("id",          sa.Integer(),  primary_key=True),
        sa.Column("key",         sa.String(64), unique=True, index=True, nullable=False),
        sa.Column("name",        sa.String(128), nullable=False),
        sa.Column("description", sa.Text(),     nullable=False),
        sa.Column("icon",        sa.String(8),  nullable=False),
        sa.Column("tier",        sa.Enum("bronze","silver","gold","platinum", name="badgetier"), default="bronze"),
        sa.Column("points",      sa.Integer(),  default=10),
        sa.Column("criteria",    sa.JSON(),     nullable=False),
        sa.Column("is_active",   sa.Boolean(),  default=True),
        sa.Column("created_at",  sa.DateTime(), default=sa.func.now()),
    )

    # ── user_badges ────────────────────────────────────────────────────────
    op.create_table(
        "user_badges",
        sa.Column("id",        sa.Integer(),  primary_key=True),
        sa.Column("user_id",   sa.Integer(),  sa.ForeignKey("users.id"),  index=True, nullable=False),
        sa.Column("badge_id",  sa.Integer(),  sa.ForeignKey("badges.id"), index=True, nullable=False),
        sa.Column("earned_at", sa.DateTime(), default=sa.func.now()),
        sa.Column("notified",  sa.Boolean(),  default=False),
        sa.UniqueConstraint("user_id", "badge_id", name="uq_user_badge"),
    )

    # ── leaderboard ────────────────────────────────────────────────────────
    op.create_table(
        "leaderboard",
        sa.Column("id",               sa.Integer(), primary_key=True),
        sa.Column("user_id",          sa.Integer(), sa.ForeignKey("users.id"), index=True, nullable=False),
        sa.Column("period",           sa.Enum("weekly","monthly","yearly","all_time", name="leaderboardperiod")),
        sa.Column("region_key",       sa.String(20), index=True, nullable=False),
        sa.Column("score",            sa.Float(),    default=0.0),
        sa.Column("rank",             sa.Integer(),  nullable=True),
        sa.Column("violations_count", sa.Integer(),  default=0),
        sa.Column("badge_count",      sa.Integer(),  default=0),
        sa.Column("updated_at",       sa.DateTime(), default=sa.func.now()),
        sa.UniqueConstraint("user_id", "period", "region_key", name="uq_leaderboard_entry"),
    )

    # ── insurance_partners ─────────────────────────────────────────────────
    op.create_table(
        "insurance_partners",
        sa.Column("id",            sa.Integer(),    primary_key=True),
        sa.Column("name",          sa.String(128),  nullable=False),
        sa.Column("logo_url",      sa.String(512),  nullable=True),
        sa.Column("discount_pct",  sa.Float(),      nullable=False),
        sa.Column("min_score",     sa.Float(),      default=70.0),
        sa.Column("description",   sa.Text(),       nullable=False),
        sa.Column("affiliate_url", sa.String(512),  nullable=True),
        sa.Column("country_codes", sa.JSON(),       default=list),
        sa.Column("is_active",     sa.Boolean(),    default=True),
        sa.Column("created_at",    sa.DateTime(),   default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("insurance_partners")
    op.drop_table("leaderboard")
    op.drop_table("user_badges")
    op.drop_table("badges")
    op.drop_table("blockchain_records")
    op.execute("DROP TYPE IF EXISTS badgetier")
    op.execute("DROP TYPE IF EXISTS leaderboardperiod")
